package com.example.work

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import com.example.work.databinding.ActivityMainBinding
import javax.net.ssl.SSLSessionBindingEvent
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    fun rand(s:Int,f:Int):Int{
        require(s<=f)
        return (s..f).random()
    }
    fun rand(num:String):Char{
      return num[Random.nextInt(num.length)]
    }
    var a=0
    var b= 0
    var move = "="
    var summ = 0


        fun startB(view:View){
            val s =10
            val f =99
            val movS="+-*/"
            a=rand(s,f)
            b=rand(s,f)
            move = rand(movS).toString()
//4 1 5
            binding.textView9.text = a.toString()
            binding.textView11.text = b.toString()
            binding.textView10.text=move
            if (move == "+"){
                summ = a + b
            }
            else if(move == "-"){
                summ = a - b
            }
            else if(move == "/"){
                summ = a / b
            }
            else
            {
                summ = a * b
            }
        }

    fun chekB(view:View){
        var a  = binding.editTextNumber.text
        var countP:Int =1
        var countS:Int =1
        if( a.toString() == summ.toString()){
            countP+=1
            binding.textView5.text= countP.toString()
        }
        else
        {
            countS+=1
            binding.textView6.text= countS.toString()
        }

        binding.textView2.text= countP.toString()
    }

}




